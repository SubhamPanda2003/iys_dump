const userModels = require('../models/userModels')
const welcome = (req, res) => {
    res.send('Welcome to the User Management System!');
};
const users = getUsers = async (req, res) => {
    let data = [];
    try {
        data = await userModels.getUsers();
        res.send({users:data});
        console.log({users: data});
    } catch (err) {
        res.json({msg: err, data: []});
    }
};


const signup = async(req, res) => {
    
    await userModels.signupUsers(req.body);
    
    
    
    res.status(201).json({ message: 'User signed up successfully' });
};
const login = async (req,res)=> {
    try{
   const userDetails= await userModels.loginUser(req.body.username,req.body.password);
   
   res.status(201).json({ message: 'login successfully done' , user: userDetails});
    }
    catch(err){
        res.status(401).json({ message: 'wrong username and password' });
    }
}
// Export the function
module.exports = { welcome,users , signup,login };

