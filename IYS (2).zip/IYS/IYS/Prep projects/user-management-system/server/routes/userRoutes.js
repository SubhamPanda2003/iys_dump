const router = require('express').Router()

const userController = require('../controllers/userController');



router.route('/getUsers').get(userController.users);

router.route('/signup').post(userController.signup);

router.route('/login').post(userController.login);

router.route('/welcome').get(userController.welcome);

module.exports = router;