const client = require('../config/db')
const { promisify } = require('util')

client.connect()

const promise_connection = promisify(client.query).bind(client)

const getUsers = async () => {

    let query = "SELECT * FROM users";
    return await promise_connection(query);
};
const signupUsers = async (req) => {
    const query = "INSERT INTO users (username, password, email) VALUES ($1, $2, $3) RETURNING *;";
    const values = [req.username, req.password, req.email];
    console.log(values);

    try {
        const result = await promise_connection(query, values);
        return result.rows[0];
    } catch (error) {
        console.error('Error executing query', error.stack);
        throw error;
    }
};

const loginUser = async (username, password) => {
    const query = 'SELECT * FROM users WHERE username = $1;';
    const values = [username];

    try {
        const res = await promise_connection(query, values);
        if (res.rows.length === 0) {
            throw new Error('Username not found');
        }

        const user = res.rows[0];
        if (user.password !== password) {  
            throw new Error('Incorrect password');
        }

        console.log('Login successful:', user);
        return user;
    } catch (err) {
        console.error('Login failed:', err.message);
        throw err;
    }
};




module.exports = { getUsers , signupUsers , loginUser};