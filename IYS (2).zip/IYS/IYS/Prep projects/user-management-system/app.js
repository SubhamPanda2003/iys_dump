const express = require('express')
const bodyParser = require('body-parser')
const mysql = require('mysql')
const client = require('./server/config/db')
const userRoutes = require('./server/routes/userRoutes')
const {Client} = require('pg')
const { promisify } = require('util')
const { application } = require('express')

require('dotenv').config()

const app = express()
const PORT = process.env.PORT || 5002

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.use('/api', userRoutes);


app.listen (PORT, () => console.log(`Listening to port: ${PORT}`));
