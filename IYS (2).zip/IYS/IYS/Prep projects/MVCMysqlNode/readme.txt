How to setup Node project:

1) npm init -y  (Use -y switch if you don't want to answers questions of package.json file)
2)npm install connect-flash express nodemon mysql express-session
3)After installing all modules then create a folder "app"
4) Inside "app" folder create following folders :
    a)config
    b)controllers
    c)models
    d)routes
    e)views
5)Now create a file "server.js" at root of the project.

3) npm run start  (to run the project)